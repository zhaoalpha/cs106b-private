/**
 * Find the max point in the given Vector.
 */
#include "random.h"
#include "testing/SimpleTest.h"
#include "vector.h"

int maxOf(Vector<int> elems) {
    (void)elems;
    // edge case

    // pick the first point

    // get the max point in the rest (someone do it for you)

    // compare your point with the max point in the rest
    return 0;
}

int maxOfDevide(Vector<int> elems) {
    (void)elems;
    // edge case

    // divide the task into two parts

    // get the max point in the first part

    // get the max point in the second part

    // compare the two max points
    return 0;
}

int maxOfRef(Vector<int> &elems, int start, int end) {
    (void)elems;
    (void)start;
    (void)end;
    // edge case

    // divide the task into two parts

    // get the max point in the first part

    // get the max point in the second part

    // compare the two max points
    return 0;
}

int main() {
    if (runSimpleTests(SELECTED_TESTS))
        return 0;

    return 0;
}

// *********************** Testing Case ****************************
